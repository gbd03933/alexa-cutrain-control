# alexa-cutrain-control
Alexa connected curtain control system

This has a large portion of the code based on the following project: https://github.com/kakopappa/arduino-esp8266-alexa-multiple-wemo-switch

Youtube project build video available here:https://youtu.be/JtYdPwO65WI
Downlaod 3D printatble parts here: https://www.thingiverse.com/thing:3174263

If you find you get an error similar to "<AF_motor.h>  No such file or directory" then please try installing this library: https://github.com/adafruit/Adafruit-Motor-Shield-library
